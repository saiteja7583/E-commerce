export const electronics = [
  {
    id: 101,
    title: "iPhone 15 Pro - Titanium Blue",
    price: 134900,
    category: "Smartphones",
    description: "Experience the power of the A17 Pro chip with a lightweight titanium design.",
    image: "https://images.unsplash.com/photo-1696446701796-da61225697cc?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 102,
    title: "iPad Pro M4 - Ultra Thin",
    price: 99900,
    category: "Tablets",
    description: "The world's most advanced display technology in the thinnest Apple design ever.",
    image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 103,
    title: "MacBook Air M3 - Midnight",
    price: 114490,
    category: "Laptops",
    description: "Strikingly thin and fast, so you can work, play, or create anywhere.",
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 104,
    title: "Sony Bravia 4K Smart TV",
    price: 84990,
    category: "Television",
    description: "Lifelike 4K HDR picture quality with the powerful 4K HDR Processor X1.",
    image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 105,
    title: "Sony WH-1000XM5 ANC",
    price: 29990,
    category: "Audio",
    description: "Industry-leading noise cancellation and magnificent sound quality.",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 106,
    title: "JBL Cinema SB271 Home Theatre",
    price: 12990,
    category: "Home Theatre",
    description: "2.1 Channel Dolby Digital Soundbar with Wireless Subwoofer for extra deep bass.",
    image: "https://images.unsplash.com/photo-1595928642581-f50f4f3453a5?q=80&w=1000&auto=format&fit=crop"
  }
];