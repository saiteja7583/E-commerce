import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './component/Navbar';
import ProductCard from './component/ProductCard';
import LoginPage from './component/LoginPage';
import { electronics } from './products'; // Import your new products

const CartPage = ({ cart, removeFromCart }) => (
  <div className="p-6 animate-fadeIn">
    <h2 className="text-3xl font-bold mb-6">Your Shopping Cart</h2>
    {cart.length === 0 ? (
      <div className="text-center py-20 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
        <p className="text-gray-500 text-xl font-medium">Your cart is empty.</p>
      </div>
    ) : (
      <div className="bg-white rounded-2xl shadow-xl p-6 border border-gray-100">
        <ul className="divide-y divide-gray-100">
          {cart.map((item, index) => (
            <li key={index} className="py-4 flex justify-between items-center px-2">
              <div className="flex items-center gap-6">
                <img src={item.image} alt={item.title} className="h-20 w-20 object-contain p-1 border rounded-lg" />
                <div>
                  <p className="font-bold text-gray-800">{item.title}</p>
                  <p className="text-blue-600 font-extrabold text-lg">₹{item.price.toLocaleString('en-IN')}</p>
                </div>
              </div>
              <button 
                onClick={() => removeFromCart(index)}
                className="bg-red-50 text-red-500 px-4 py-2 rounded-xl hover:bg-red-500 hover:text-white transition-all font-bold"
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
        <div className="mt-8 border-t pt-6 text-right">
          <p className="text-3xl font-black text-gray-900">
            Total: ₹{cart.reduce((sum, item) => sum + item.price, 0).toLocaleString('en-IN')}
          </p>
          <button className="mt-6 bg-gradient-to-r from-blue-600 to-indigo-700 text-white px-10 py-3 rounded-2xl hover:shadow-2xl transition-all font-black text-lg shadow-lg">
            Checkout Now
          </button>
        </div>
      </div>
    )}
  </div>
);

function App() {
  const [products, setProducts] = useState(electronics); // Use your local data directly
  const [cart, setCart] = useState([]);
  const [showToast, setShowToast] = useState(false);

  const addToCart = (product) => {
    setCart([...cart, product]);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 2000);
  };

  const removeFromCart = (indexToRemove) => {
    setCart(cart.filter((_, index) => index !== indexToRemove));
  };

  return (
    <Router>
      {showToast && (
        <div className="fixed top-24 right-5 z-[100] bg-white border-l-8 border-green-500 text-gray-800 px-8 py-4 rounded-xl shadow-2xl flex items-center gap-3 animate-bounce font-bold">
          🛒 Added to your cart!
        </div>
      )}

      <Navbar cartCount={cart.length} />
      
      <div className="container mx-auto p-4 pt-10">
        <Routes>
          <Route path="/" element={
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 animate-fadeIn">
              {products.map(p => (
                <ProductCard key={p.id} product={p} addToCart={addToCart} />
              ))}
            </div>
          } />
          <Route path="/cart" element={<CartPage cart={cart} removeFromCart={removeFromCart} />} />
          <Route path="/login" element={<LoginPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;