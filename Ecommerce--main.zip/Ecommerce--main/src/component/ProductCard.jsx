const ProductCard = ({ product, addToCart }) => {
  return (
    <div className="group bg-white border border-gray-100 p-6 rounded-3xl shadow-sm hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-3 flex flex-col justify-between relative h-full">
      
      {/* Category Badge - Shows the device type */}
      <div className="absolute top-4 left-4 z-10">
        <span className="bg-blue-100 text-blue-600 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest shadow-sm">
          {product.category}
        </span>
      </div>

      {/* Image Container with Advanced Zoom Effect */}
      <div className="relative overflow-hidden rounded-2xl bg-white mb-6 flex items-center justify-center h-52 w-full border border-gray-50 shadow-inner">
        <img 
          src={product.image} 
          alt={product.title} 
          className="h-44 w-auto object-contain transition-transform duration-700 group-hover:scale-125" 
          // This fixes the blank image problem by showing a clear placeholder if the link fails
          onError={(e) => { 
            e.target.src = 'https://via.placeholder.com/300?text=Electronic+Device'; 
          }} 
        />
        {/* Subtle overlay that appears on hover */}
        <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
      </div>

      <div>
        {/* Professional Rating UI */}
        <div className="flex items-center gap-1 text-yellow-400 text-xs mb-3">
          <span className="flex">★★★★★</span>
          <span className="text-gray-400 font-bold ml-1 tracking-tighter">(4.5)</span>
        </div>

        <h3 className="font-extrabold text-gray-900 text-base h-12 overflow-hidden mb-2 leading-tight group-hover:text-blue-600 transition-colors">
          {product.title}
        </h3>
        
        <p className="text-gray-500 text-xs mb-6 line-clamp-2 h-8 leading-relaxed">
          {product.description}
        </p>
        
        {/* Pricing and Action Section */}
        <div className="flex justify-between items-center pt-4 border-t border-gray-100">
          <div className="flex flex-col">
            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Special Price</span>
            <span className="text-blue-600 font-black text-xl italic drop-shadow-sm">
              ₹{product.price.toLocaleString('en-IN')}
            </span>
          </div>
          <button 
            onClick={() => addToCart(product)}
            className="bg-blue-600 hover:bg-black text-white px-6 py-2.5 rounded-2xl text-xs font-black transition-all duration-300 shadow-lg hover:shadow-blue-200 active:scale-90 flex items-center gap-2"
          >
            Buy Now
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;