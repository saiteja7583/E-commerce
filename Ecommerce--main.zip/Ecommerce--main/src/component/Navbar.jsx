import { Link } from 'react-router-dom';
import { ShoppingCart, Store } from 'lucide-react';

const Navbar = ({ cartCount }) => {
  return (
    <nav className="flex justify-between items-center p-4 bg-blue-600 text-white shadow-lg sticky top-0 z-50">
      <Link to="/" className="text-2xl font-bold flex items-center gap-2">
        <Store /> MyShop
      </Link>
      
      <div className="flex gap-6 items-center">
        <Link to="/" className="hover:underline">Home</Link>
        
        {/* Added Login Link */}
        <Link to="/login" className="hover:underline bg-white text-blue-600 px-3 py-1 rounded-md font-medium">
          Login
        </Link>

        <Link to="/cart" className="relative">
          <ShoppingCart size={28} />
          {cartCount > 0 && (
            <span className="absolute -top-2 -right-2 bg-red-500 text-xs rounded-full px-2 py-1">
              {cartCount}
            </span>
          )}
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;