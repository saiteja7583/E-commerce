import { useState } from 'react';

const LoginPage = () => {
  const [isRegister, setIsRegister] = useState(false);
  const [formData, setFormData] = useState({ email: '', password: '', name: '' });

  const handleSubmit = (e) => {
    e.preventDefault();
    const action = isRegister ? "Registered" : "Logged in";
    alert(`${action} successfully as ${formData.email}`);
  };

  return (
    <div className="flex justify-center items-center min-h-[70vh] animate-fadeIn">
      <form onSubmit={handleSubmit} className="bg-white p-8 rounded-2xl shadow-2xl w-full max-w-md border border-gray-100 transform transition-all hover:scale-[1.01]">
        <h2 className="text-3xl font-extrabold mb-6 text-center text-blue-600">
          {isRegister ? 'Create Account' : 'Welcome Back'}
        </h2>
        
        {isRegister && (
          <div className="mb-4 animate-slideDown">
            <label className="block text-sm font-semibold mb-1 text-gray-600">Full Name</label>
            <input 
              type="text" 
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-400 outline-none transition-all"
              placeholder="John Doe"
              onChange={(e) => setFormData({...formData, name: e.target.value})}
            />
          </div>
        )}

        <div className="mb-4">
          <label className="block text-sm font-semibold mb-1 text-gray-600">Email</label>
          <input 
            type="email" 
            required 
            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-400 outline-none transition-all"
            placeholder="name@company.com"
            onChange={(e) => setFormData({...formData, email: e.target.value})}
          />
        </div>

        <div className="mb-6">
          <label className="block text-sm font-semibold mb-1 text-gray-600">Password</label>
          <input 
            type="password" 
            required 
            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-400 outline-none transition-all"
            placeholder="••••••••"
          />
        </div>

        <button type="submit" className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 hover:shadow-lg active:scale-95 transition-all mb-4">
          {isRegister ? 'Sign Up' : 'Sign In'}
        </button>

        <p className="text-center text-gray-500 text-sm">
          {isRegister ? 'Already have an account?' : "Don't have an account?"} 
          <button 
            type="button"
            onClick={() => setIsRegister(!isRegister)}
            className="ml-1 text-blue-600 font-bold hover:underline"
          >
            {isRegister ? 'Login' : 'Register Now'}
          </button>
        </p>
      </form>
    </div>
  );
};

export default LoginPage;